# LEADEER — MVP

Aplicação para encontrar empresas por segmento/região, priorizar negócios sem site e exportar leads em CSV.

## Como rodar

Requisitos:
- Node.js 18+

No terminal:

```bash
npm install
npm run dev
```

Abra http://localhost:3000

## Fonte de dados

O MVP usa OpenStreetMap/Nominatim/Overpass para evitar dependência inicial de Google Cloud e cartão.

### Limitações importantes
- Não é uma busca ilimitada de Google Maps.
- A qualidade depende do que estiver cadastrado no OpenStreetMap.
- O campo "sem site" significa "nenhum site encontrado nos dados consultados", não prova absoluta de que a empresa não possui site.
- Nominatim/Overpass têm políticas e limites de uso; para produção em escala, use uma instância própria ou um provedor adequado.
- Não raspe o Google Maps para contornar limites ou cobrança.

## Próximas evoluções

1. Importar Google Places opcionalmente com chave do próprio usuário.
2. Verificar automaticamente se domínios respondem.
3. Melhorar score com telefone, Instagram e sinais de presença digital.
4. Histórico de leads e botão "já contatado".
5. Login e banco de dados.
6. Exportação XLSX/CSV.
7. Geração automática de mensagem de prospecção.
