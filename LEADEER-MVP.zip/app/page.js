"use client";

import { useState } from "react";

function csvEscape(v) {
  return `"${String(v ?? "").replaceAll('"', '""')}"`;
}

export default function Home() {
  const [category, setCategory] = useState("odontologia");
  const [city, setCity] = useState("Rio de Janeiro, RJ");
  const [minRating, setMinRating] = useState("4");
  const [onlyNoSite, setOnlyNoSite] = useState(true);
  const [results, setResults] = useState([]);
  const [loading, setLoading] = useState(false);
  const [message, setMessage] = useState("");

  async function search() {
    setLoading(true);
    setMessage("");
    try {
      const r = await fetch("/api/search", {
        method: "POST",
        headers: {"Content-Type": "application/json"},
        body: JSON.stringify({ category, city, minRating: Number(minRating), onlyNoSite })
      });
      const data = await r.json();
      if (!r.ok) throw new Error(data.error || "Erro na busca.");
      setResults(data.results);
      setMessage(`${data.results.length} leads encontrados.`);
    } catch (e) {
      setMessage(e.message);
    } finally {
      setLoading(false);
    }
  }

  function exportCsv() {
    const header = ["Score","Empresa","Categoria","Avaliação","Avaliações","Site","Telefone","Instagram","Localização","Mapa"];
    const rows = results.map(x => [
      x.score, x.name, x.category, x.rating, x.reviews, x.website || "NÃO ENCONTRADO",
      x.phone || "", x.instagram || "", x.address || "", x.mapUrl || ""
    ]);
    const csv = [header, ...rows].map(row => row.map(csvEscape).join(",")).join("\n");
    const blob = new Blob(["\ufeff" + csv], {type: "text/csv;charset=utf-8"});
    const a = document.createElement("a");
    a.href = URL.createObjectURL(blob);
    a.download = "leads-leadeer.csv";
    a.click();
    URL.revokeObjectURL(a.href);
  }

  return (
    <main>
      <section className="hero">
        <div className="brand">LEADEER</div>
        <h1>Encontre empresas que podem precisar de um site.</h1>
        <p>Pesquisa negócios por categoria e cidade, prioriza empresas sem site e calcula um score de oportunidade.</p>
      </section>

      <section className="panel">
        <div className="grid">
          <label>Segmento
            <input value={category} onChange={e=>setCategory(e.target.value)} placeholder="ex.: clínica odontológica" />
          </label>
          <label>Cidade / região
            <input value={city} onChange={e=>setCity(e.target.value)} placeholder="ex.: Rio de Janeiro, RJ" />
          </label>
          <label>Avaliação mínima
            <select value={minRating} onChange={e=>setMinRating(e.target.value)}>
              <option value="0">Qualquer</option>
              <option value="3">3,0+</option>
              <option value="4">4,0+</option>
              <option value="4.5">4,5+</option>
            </select>
          </label>
        </div>
        <label className="check">
          <input type="checkbox" checked={onlyNoSite} onChange={e=>setOnlyNoSite(e.target.checked)} />
          Mostrar prioritariamente empresas sem site
        </label>
        <button onClick={search} disabled={loading}>{loading ? "Pesquisando..." : "🔎 Encontrar leads"}</button>
        <div className="hint">Fonte inicial: OpenStreetMap/Overpass. Não exige cartão nem Google Cloud.</div>
      </section>

      {message && <div className="message">{message}</div>}

      {results.length > 0 && (
        <section className="results">
          <div className="resultsTop">
            <h2>Leads encontrados</h2>
            <button className="secondary" onClick={exportCsv}>Exportar CSV</button>
          </div>
          {results.map((x, i) => (
            <article className="lead" key={i}>
              <div className="score">{x.score}<small>/100</small></div>
              <div className="leadMain">
                <h3>{x.name}</h3>
                <div className="meta">⭐ {x.rating ? x.rating.toFixed(1) : "—"} · {x.reviews ?? 0} avaliações · {x.category || "empresa"}</div>
                <div className="status">{x.website ? "🌐 Site encontrado" : "🔥 SEM SITE ENCONTRADO"}</div>
                <div className="details">
                  {x.phone && <span>📞 {x.phone}</span>}
                  {x.instagram && <span>📸 {x.instagram}</span>}
                  {x.address && <span>📍 {x.address}</span>}
                </div>
                <div className="actions">
                  {x.phone && <a href={"https://wa.me/" + x.phone.replace(/\D/g,"")} target="_blank">WhatsApp</a>}
                  {x.website && <a href={x.website} target="_blank">Site</a>}
                  {x.mapUrl && <a href={x.mapUrl} target="_blank">Mapa</a>}
                </div>
              </div>
            </article>
          ))}
        </section>
      )}
    </main>
  );
}
