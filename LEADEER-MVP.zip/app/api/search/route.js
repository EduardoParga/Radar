import { NextResponse } from "next/server";

const OVERPASS = "https://overpass-api.de/api/interpreter";
const NOMINATIM = "https://nominatim.openstreetmap.org/search";

function score(x) {
  let s = 45;
  if (!x.website) s += 30;
  if ((x.rating || 0) >= 4.5) s += 10;
  else if ((x.rating || 0) >= 4) s += 6;
  if ((x.reviews || 0) >= 100) s += 10;
  else if ((x.reviews || 0) >= 30) s += 6;
  if (x.phone) s += 3;
  if (x.instagram) s += 2;
  return Math.min(100, s);
}

export async function POST(req) {
  try {
    const body = await req.json();
    const category = String(body.category || "empresa").trim();
    const city = String(body.city || "Rio de Janeiro, RJ").trim();
    const minRating = Number(body.minRating || 0);
    const onlyNoSite = Boolean(body.onlyNoSite);

    const geo = await fetch(`${NOMINATIM}?format=jsonv2&limit=1&q=${encodeURIComponent(city)}`, {
      headers: {"User-Agent": "LEADEER/1.0 contact@example.com"}
    });
    if (!geo.ok) throw new Error("Não foi possível localizar a cidade.");
    const places = await geo.json();
    if (!places.length) throw new Error("Cidade/região não encontrada.");

    const lat = Number(places[0].lat);
    const lon = Number(places[0].lon);

    const q = `
      [out:json][timeout:30];
      (
        nwr(around:25000,${lat},${lon})["name"];
      );
      out center tags;
    `;

    const ov = await fetch(OVERPASS, {
      method: "POST",
      headers: {"Content-Type": "application/x-www-form-urlencoded"},
      body: "data=" + encodeURIComponent(q)
    });
    if (!ov.ok) throw new Error("A fonte de dados está temporariamente ocupada. Tente novamente em alguns segundos.");
    const data = await ov.json();

    const wanted = category.toLowerCase().split(/\s+/).filter(Boolean);
    let arr = data.elements.map(e => {
      const t = e.tags || {};
      const hay = [
        t.name, t["name:pt"], t.amenity, t.shop, t.office, t.healthcare,
        t["healthcare:speciality"], t.description, t.cuisine
      ].filter(Boolean).join(" ").toLowerCase();

      const matches = wanted.some(w => hay.includes(w)) || category === "empresa";
      if (!matches) return null;

      const lat2 = e.lat ?? e.center?.lat;
      const lon2 = e.lon ?? e.center?.lon;
      const website = t.website || t["contact:website"] || "";
      const phone = t.phone || t["contact:phone"] || "";
      const instagram = t["contact:instagram"] || t.instagram || "";
      const rating = t.stars ? Number(t.stars) : 0;
      const reviews = t["review:count"] ? Number(t["review:count"]) : 0;
      const address = [t["addr:street"], t["addr:housenumber"], t["addr:suburb"], t["addr:city"]].filter(Boolean).join(", ");

      return {
        name: t.name || t["name:pt"] || "Empresa sem nome",
        category: t.amenity || t.shop || t.office || t.healthcare || category,
        rating: Number.isFinite(rating) ? rating : 0,
        reviews: Number.isFinite(reviews) ? reviews : 0,
        website,
        phone,
        instagram,
        address,
        mapUrl: lat2 && lon2 ? `https://www.openstreetmap.org/?mlat=${lat2}&mlon=${lon2}#map=18/${lat2}/${lon2}` : "",
        score: 0
      };
    }).filter(Boolean);

    arr = arr.filter(x => x.rating >= minRating);
    arr = arr.map(x => ({...x, score: score(x)}));
    if (onlyNoSite) arr = arr.filter(x => !x.website);
    arr.sort((a,b) => b.score - a.score);
    arr = arr.slice(0, 100);

    return NextResponse.json({results: arr});
  } catch (e) {
    return NextResponse.json({error: e.message || "Erro inesperado."}, {status: 500});
  }
}
