import "./globals.css";

export const metadata = {
  title: "LEADEER — Prospectador",
  description: "Encontre empresas com alta oportunidade de site."
};

export default function RootLayout({ children }) {
  return (
    <html lang="pt-BR">
      <body>{children}</body>
    </html>
  );
}
